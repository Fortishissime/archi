#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

APP = Path("/app")
PLAYERS = Path("/data/players")
APWORLDS = Path("/data/apworld")
OUTPUT = Path("/data/output")
SAVES = Path("/data/saves")
STATE = Path("/data/state")
CUSTOM_WORLDS = APP / "custom_worlds"

FINGERPRINT_FILE = STATE / "generation.sha256"
CURRENT_ARCHIVE_FILE = STATE / "current_archive.txt"


def env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def run(command: list[str], *, cwd: Path = APP) -> None:
    print("+", " ".join(command), flush=True)
    subprocess.run(command, cwd=cwd, check=True)


def ensure_directories() -> None:
    for directory in (PLAYERS, APWORLDS, OUTPUT, SAVES, STATE, CUSTOM_WORLDS):
        directory.mkdir(parents=True, exist_ok=True)


def player_files() -> list[Path]:
    return sorted(
        (
            path for path in PLAYERS.iterdir()
            if path.is_file()
            and not path.name.startswith(".")
            and path.suffix.lower() in {".yaml", ".yml"}
        ),
        key=lambda path: path.name.casefold(),
    )


def apworld_files() -> list[Path]:
    return sorted(
        (
            path for path in APWORLDS.iterdir()
            if path.is_file()
            and not path.name.startswith(".")
            and path.suffix.lower() == ".apworld"
        ),
        key=lambda path: path.name.casefold(),
    )


def hash_inputs(players: list[Path], apworlds: list[Path]) -> str:
    digest = hashlib.sha256()
    digest.update(os.getenv("ARCHIPELAGO_VERSION", "0.6.7").encode())
    digest.update(os.getenv("AP_RACE", "false").encode())
    digest.update(os.getenv("AP_SPOILER", "2").encode())

    for category, paths in (("player", players), ("apworld", apworlds)):
        for path in paths:
            digest.update(category.encode())
            digest.update(path.name.encode("utf-8"))
            with path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(chunk)
    return digest.hexdigest()


def sync_apworlds(apworlds: list[Path]) -> None:
    # Le répertoire est interne au conteneur : on le remet à zéro à chaque démarrage.
    for child in CUSTOM_WORLDS.iterdir():
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()

    for source in apworlds:
        destination = CUSTOM_WORLDS / source.name
        shutil.copy2(source, destination)
        print(f"APWorld chargé : {source.name}", flush=True)


def install_apworld_requirements(apworlds: list[Path]) -> None:
    requirement_files: list[Path] = []

    with tempfile.TemporaryDirectory(prefix="apworld-requirements-") as temp_dir:
        temp_root = Path(temp_dir)

        for index, apworld in enumerate(apworlds):
            try:
                with zipfile.ZipFile(apworld) as archive:
                    candidates = [
                        name for name in archive.namelist()
                        if Path(name).name.lower() == "requirements.txt"
                        and not name.endswith("/")
                    ]
                    for candidate_index, member in enumerate(candidates):
                        target = temp_root / f"{index}-{candidate_index}-requirements.txt"
                        target.write_bytes(archive.read(member))
                        requirement_files.append(target)
                        print(
                            f"Dépendances détectées dans {apworld.name}: {member}",
                            flush=True,
                        )
            except zipfile.BadZipFile as exc:
                raise RuntimeError(
                    f"{apworld.name} n'est pas un fichier .apworld ZIP valide."
                ) from exc

        for requirements in requirement_files:
            run([
                sys.executable, "-m", "pip", "install",
                "--no-cache-dir", "-r", str(requirements),
            ])


def current_archive() -> Path | None:
    if not CURRENT_ARCHIVE_FILE.exists():
        return None
    value = CURRENT_ARCHIVE_FILE.read_text(encoding="utf-8").strip()
    if not value:
        return None
    path = OUTPUT / value
    return path if path.is_file() else None


def newest_generated_archive(previous: set[Path]) -> Path:
    archives = {
        path.resolve()
        for path in OUTPUT.glob("*.archipelago")
        if path.is_file()
    }
    new_archives = archives - previous
    candidates = new_archives or archives
    if not candidates:
        raise RuntimeError(
            "La génération n'a produit aucun fichier .archipelago."
        )
    return max(candidates, key=lambda path: path.stat().st_mtime_ns)


def generate(players: list[Path], fingerprint: str) -> Path:
    previous = {
        path.resolve()
        for path in OUTPUT.glob("*.archipelago")
        if path.is_file()
    }

    command = [
        sys.executable,
        "Generate.py",
        "--player_files_path", str(PLAYERS),
        "--outputpath", str(OUTPUT),
        "--spoiler", os.getenv("AP_SPOILER", "2"),
    ]
    if env_bool("AP_RACE"):
        command.append("--race")

    run(command)
    archive = newest_generated_archive(previous)

    FINGERPRINT_FILE.write_text(fingerprint + "\n", encoding="utf-8")
    CURRENT_ARCHIVE_FILE.write_text(archive.name + "\n", encoding="utf-8")
    print(f"Nouvelle partie générée : {archive.name}", flush=True)
    return archive


def choose_archive(players: list[Path], apworlds: list[Path]) -> Path:
    fingerprint = hash_inputs(players, apworlds)
    stored_fingerprint = (
        FINGERPRINT_FILE.read_text(encoding="utf-8").strip()
        if FINGERPRINT_FILE.exists()
        else ""
    )
    archive = current_archive()

    must_generate = (
        env_bool("AP_FORCE_REGENERATE")
        or archive is None
        or fingerprint != stored_fingerprint
    )

    if must_generate:
        return generate(players, fingerprint)

    print(f"Entrées inchangées : réutilisation de {archive.name}", flush=True)
    return archive


def start_server(archive: Path) -> None:
    port = os.getenv("AP_PORT", "38281")
    save_file = SAVES / f"{archive.stem}.apsave"

    command = [
        sys.executable,
        "MultiServer.py",
        str(archive),
        "--host", "0.0.0.0",
        "--port", port,
        "--savefile", str(save_file),
        "--loglevel", os.getenv("AP_LOG_LEVEL", "info"),
    ]

    password = os.getenv("AP_PASSWORD", "")
    server_password = os.getenv("AP_SERVER_PASSWORD", "")
    if password:
        command.extend(["--password", password])
    if server_password:
        command.extend(["--server_password", server_password])

    print(f"Démarrage du serveur avec {archive.name}", flush=True)
    print(f"Sauvegarde : {save_file}", flush=True)
    os.execv(sys.executable, command)


def main() -> None:
    ensure_directories()

    players = player_files()
    if not players:
        raise RuntimeError(
            "Aucun fichier .yaml ou .yml trouvé dans le dossier ./players."
        )

    apworlds = apworld_files()
    print(f"{len(players)} fichier(s) joueur détecté(s).", flush=True)
    print(f"{len(apworlds)} APWorld custom détecté(s).", flush=True)

    sync_apworlds(apworlds)
    install_apworld_requirements(apworlds)
    archive = choose_archive(players, apworlds)
    start_server(archive)


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as exc:
        print(
            f"Une commande a échoué avec le code {exc.returncode}.",
            file=sys.stderr,
            flush=True,
        )
        raise
    except Exception as exc:
        print(f"ERREUR : {exc}", file=sys.stderr, flush=True)
        sys.exit(1)
