# Serveur Archipelago Docker

Cette configuration utilise Archipelago 0.6.7.

## Utilisation

1. Dépose les YAML des joueurs dans `players/`.
2. Dépose les mondes custom `.apworld` dans `apworld/`.
3. Copie `.env.example` vers `.env` si tu veux modifier les réglages.
4. Lance :

```bash
docker compose up -d --build
docker compose logs -f
```

Le conteneur :

- détecte les YAML et les APWorlds ;
- installe les éventuelles dépendances `requirements.txt` embarquées ;
- génère automatiquement le `.archipelago` ;
- lance `MultiServer.py` sur le port 38281 ;
- conserve la seed dans `output/` et la sauvegarde serveur dans `saves/`.

## Redémarrages

Un simple redémarrage ne régénère pas la partie. La seed existante est réutilisée.

Une nouvelle seed est générée automatiquement lorsque :

- un YAML joueur est ajouté, retiré ou modifié ;
- un `.apworld` est ajouté, retiré ou modifié ;
- `AP_RACE` ou `AP_SPOILER` change ;
- `AP_FORCE_REGENERATE=true`.

Après une génération forcée, remets `AP_FORCE_REGENERATE=false`.

## Commandes utiles

```bash
docker compose up -d --build
docker compose logs -f
docker compose restart
docker compose down
```

## Connexion

Les joueurs se connectent à :

```text
adresse-du-serveur:38281
```

Ouvre/redirige le port TCP 38281 dans le pare-feu et la box si nécessaire.

## Sécurité

Un `.apworld` contient du code Python et peut demander l'installation de
dépendances. N'utilise que des APWorlds provenant de sources de confiance.
